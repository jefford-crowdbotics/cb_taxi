# Installation Notes

This package requires at least Python 3.6.

To install module through Github, run:

```
python3 -m pip install git+https://github.com/jefford-crowdbotics/cb_taxi.git
```

# Testing

Test files are located in `tests/` folder
```
python3 test_app.py
```
